LaTeX source for the approved NLS loop-transport manuscript.

Build: pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex (twice).
Requires REVTeX 4.2 and the packages declared in manuscript.tex. Five PDF figures are included.
Scientific text is the approved 3 October 2026 version; correspondence email is updated to alumni.
Data availability now cites the public Zenodo dataset, DOI 10.5281/zenodo.23223225. Scientific content is unchanged.
