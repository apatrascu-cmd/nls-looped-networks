"""LINEAR Gaussian packet on a degree-3 Kirchhoff star (exact R=1/9, T=4/9 each): lumped scheme vs 2nd-order constraint scheme.
Also: static check of the constraint row on an exact linear star solution, and CTRL-K (Kirchhoff residual) with dt ~ h^2."""
import sys, numpy as np, time, scipy.sparse as sp, scipy.sparse.linalg as spla
import pde_solver as P, pde_solver2 as P2
t0 = time.time(); log = lambda *a: (print(*a), sys.stdout.flush())
class LinProp1:
    def __init__(s, G, dt):
        I = sp.identity(G.N, format='csr', dtype=complex); s.lu = spla.splu((I - 1j*dt/2*G.D2).tocsc()); s.B = (I + 1j*dt/2*G.D2).tocsr()
    def step(s, q): return s.lu.solve(s.B.dot(q))
class LinProp2:
    def __init__(s, G, dt):
        I = sp.identity(G.N, format='csr', dtype=complex); A = (I - 1j*dt/2*G.L).tolil(); B = (I + 1j*dt/2*G.L).tolil()
        for iv in G.vid.values(): A[iv, :] = G.C[iv, :].toarray().ravel(); B[iv, :] = 0.0
        s.lu = spla.splu(A.tocsc()); s.B = B.tocsr()
    def step(s, q): return s.lu.solve(s.B.dot(q))
def build(scheme, h):
    G = (P.MetricGraph if scheme == 1 else P2.MetricGraph2)(h_target=h)
    for n in ('E0', 'V', 'E1', 'E2'): G.add_vertex(n)
    E = [G.add_edge('E0', 'V', 30.0), G.add_edge('V', 'E1', 30.0), G.add_edge('V', 'E2', 30.0)]; G.build(); return G, E
# --- static check: exact linear star solution at fixed time, r=-1/3, t=2/3, k=2; constraint residual should be O(h^2)
log("STATIC check of the constraint row on the exact linear star solution (k=2, r=-1/3, t=2/3):")
for h in (0.04, 0.02, 0.01):
    G, E = build(2, h); q = np.zeros(G.N, complex); k = 2.0
    y0 = 30.0 - G.edge_x(E[0])                      # distance from V along the incoming edge (outward coordinate)
    G.scatter_edge(q, E[0], np.exp(-1j*k*y0) - (1/3)*np.exp(1j*k*y0))
    for e in (E[1], E[2]): G.scatter_edge(q, e, (2/3)*np.exp(1j*k*G.edge_x(e)))
    r = G.C.dot(q)[G.vid['V']]; log(f"  h={h}: |C q|_V = {abs(r):.3e}  (normalised by k: {abs(r)/k:.3e})")
log("\nLINEAR packet (k=2, width 2) on the star; exact R=0.11111, T=0.44444 each; dt=1e-4 for all h")
for h in (0.04, 0.02, 0.01):
    for scheme in (1, 2):
        G, E = build(scheme, h); x0 = G.edge_x(E[0]); q = np.zeros(G.N, complex)
        G.scatter_edge(q, E[0], np.exp(-(x0-15.0)**2/8.0)*np.exp(2j*x0))
        m = lambda q: sum(np.trapz(np.abs(G.gather_edge(q, ei))**2, dx=G.edges[ei]['h']) for ei in E); m0 = m(q)
        prop = (LinProp1 if scheme == 1 else LinProp2)(G, 1e-4)
        for kk in range(int(5.75/1e-4)): q = prop.step(q)
        fr = [np.trapz(np.abs(G.gather_edge(q, ei))**2, dx=G.edges[ei]['h'])/m0 for ei in E]
        log(f"  scheme {scheme} ({'lumped' if scheme==1 else 'constraint'}) h={h}: R={fr[0]:.5f} T1={fr[1]:.5f} T2={fr[2]:.5f} mass drift {abs(m(q)-m0)/m0:.1e}  [{time.time()-t0:.0f}s]")
log("\nCTRL-K redo (dt ~ h^2): Kirchhoff residual at B, 4-point formula, theta (6,10,8), soliton on e2, t in [2,4]")
for h, dt in ((0.02, 2e-4), (0.01, 5e-5)):
    G = P2.MetricGraph2(h); G.add_vertex('A'); G.add_vertex('B'); E = [G.add_edge('A', 'B', L) for L in (6.0, 10.0, 8.0)]; G.build()
    q = np.zeros(G.N, complex); G.scatter_edge(q, E[1], P.soliton_field(G.edge_x(E[1]), 0.8, -0.5, 5.0)); prop = P2.NLSPropagator2(G, dt); res = []
    for kk in range(1, int(4.0/dt)+1):
        q = prop.step(q)
        if kk % int(0.05/dt) == 0 and kk*dt > 2.0:
            d = [P2.d_out_4pt(G.gather_edge(q, ei), G.edges[ei]['h'], 'B') for ei in E]; res.append(abs(sum(d))/max(abs(x) for x in d))
    log(f"  h={h}, dt={dt}: median {np.median(res):.2e}, max {np.max(res):.2e}   [{time.time()-t0:.0f}s]")
