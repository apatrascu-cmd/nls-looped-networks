"""Independent local-Lax and stationary graph controls; no PDE campaign rerun."""
import json, os
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp, quad
from scipy.linalg import expm
import sympy as S

assert int(os.environ['PYSCF_MAX_MEMORY']) > 0
I = np.eye(2, dtype=complex)
sigma = np.diag([1., -1.])

def V(q, p, z):
    return np.array([[-2j*z*z+1j*abs(q)**2, 2*z*q+1j*p],
                     [-2*z*np.conj(q)+1j*np.conj(p), 2j*z*z-1j*abs(q)**2]])

# Known-true Corrigan--Zambon jump defect in the manuscript's conventions.
rng = np.random.default_rng(12813)
worst = 0.
for _ in range(30):
    u, v, p, ut = (rng.normal(size=2).view(complex)[0] * .35 for j in range(4))
    alpha = 2.
    delta = u-v
    omega = np.sqrt(alpha**2-abs(delta)**2)
    vx = p-omega*(u+v)
    delta_t = 1j*omega*(p+vx)+1j*delta*(abs(u)**2+abs(v)**2)
    vt = ut-delta_t
    omega_t = -np.real(np.conj(delta)*delta_t)/omega
    K0 = .5j*np.array([[-omega,delta],[np.conj(delta),omega]])
    Kdot = .5j*np.array([[-omega_t,delta_t],[np.conj(delta_t),omega_t]])
    for z in [-.8, 0., .6, .4+.2j]:
        K = z*I+K0
        residual = Kdot - (V(v,vx,z)@K-K@V(u,p,z))
        worst = max(worst, float(np.max(np.abs(residual))))
        assert abs(np.linalg.det(K)-(z*z+alpha*alpha/4)) < 1e-12
assert worst < 1e-11, worst

# Highest coefficient of the general polynomial recurrence: diagonal cancellation.
a,b,u,ub,v,vb,ux,ubx,vx,vbx=S.symbols('a b u ub v vb ux ubx vx vbx')
Qu=S.Matrix([[0,u],[-ub,0]]); Qv=S.Matrix([[0,v],[-vb,0]])
Ru=S.I*S.Matrix([[u*ub,ux],[ubx,-u*ub]])
Rv=S.I*S.Matrix([[v*vb,vx],[vbx,-v*vb]])
Kn=S.diag(a,b)
previous=S.Matrix([[S.Symbol('c1'),S.I*(a*u-b*v)/2],
                   [S.I*(b*ub-a*vb)/2,S.Symbol('c2')]])
diag_rhs=2*(Qv*previous-previous*Qu)+Rv*Kn-Kn*Ru
assert all(S.simplify(diag_rhs[j,j])==0 for j in (0,1))

# Exact standing-wave family, checked by independent spatial integration.
# f''=2 c^2 f-2 f^3, f(0)=c, f'(0)=s. Two oscillatory edges
# have derivatives +/-s; a third edge is constant. At each end Kirchhoff holds.
def edge(s, L, phase, z=.6):
    def rhs(x,y):
        f,fp=y[0].real,y[1].real
        q=np.exp(1j*phase)*f
        U=np.array([[-1j*z,q],[-np.conj(q),1j*z]])
        return np.r_[fp,2*f-2*f**3,(U@y[2:].reshape(2,2)).ravel()]
    result=solve_ivp(rhs,[0,L],np.r_[1.+0j,s+0j,I.ravel()],
                     method='DOP853',rtol=2e-11,atol=2e-12)
    assert result.success
    return result.y[:2,-1],result.y[2:,-1].reshape(2,2)

curve=[]
for s in [0., .15, .3, .6]:
    L=quad(lambda theta: 1/np.sqrt(1+s*np.sin(theta)),
           -np.pi/2,np.pi/2,epsabs=1e-12,epsrel=1e-12)[0]
    endpoints,T1=edge(s,L,0.)
    endpoints2,T2=edge(-s,L,0.)
    _,T1t=edge(s,L,.8)
    z=.6
    U3=np.array([[-1j*z,1.],[-1.,1j*z]])
    T3=expm(1.1*U3)
    U3t=np.array([[-1j*z,np.exp(.8j)],[-np.exp(-.8j),1j*z]])
    T3t=expm(1.1*U3t)
    HA=T3@T1; HB=T1@T3
    FA=1j*np.array([[0.,-s],[-s,0.]])
    FB=-FA
    termA=np.trace(HA@FA); termB=np.trace(HB@FB)
    row=dict(s=s,period=L,vertex_defect_norm=float(np.linalg.norm(FA)),
             trace_change=float(abs(np.trace(T3t@T1t)-np.trace(HA))),
             total_defect_pairing=float(abs(termA+termB)),
             individual_pairing=float(abs(termA)),
             endpoint_error=float(max(np.max(abs(endpoints-[1.,s])),np.max(abs(endpoints2-[1.,-s])))))
    assert row['trace_change'] < 2e-9, row
    assert row['total_defect_pairing'] < 2e-9, row
    assert row['endpoint_error'] < 2e-9, row
    curve.append(row)

out=dict(status='passed',cz_samples=30,cz_max_residual=worst,
         polynomial_highest_diagonal='exact symbolic zero',standing_wave_curve=curve)
Path(__file__).with_name('control_results.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
