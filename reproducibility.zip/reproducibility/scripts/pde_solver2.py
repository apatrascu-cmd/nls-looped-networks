"""Graph NLS solver with a SECOND-ORDER vertex treatment.
Same grid and Strang/Crank-Nicolson structure as pde_solver.py, but the vertex degree of freedom is governed by the
discrete Kirchhoff/delta constraint built from second-order one-sided derivatives,
      sum_e (3 q_v - 4 q_e^(1) + q_e^(2)) / (2 h_e)  =  g q_v        (outward derivatives; g = delta strength, 0 = Kirchhoff),
imposed as a constraint row in the Crank-Nicolson system (A q+ = B q with A[v,:] = C[v,:], B[v,:] = 0).
The lumped-mass scheme of pde_solver.py is first-order accurate at the vertex; this one is second-order there.
Price: the linear step is no longer exactly unitary (mass conserved to discretisation accuracy, monitored).
Controls (run as __main__): A stationary soliton, B moving soliton, C delta-vertex HMZ trend, D degree-3 Kirchhoff star R=1/9,
K discrete Kirchhoff residual at a degree-3 vertex measured with an independent 4-point formula (should be O(h^2)).
"""
import os, time, numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spla
from pde_solver import soliton_field
t0 = time.time()
def el(): return "[t=%6.1fs]" % (time.time() - t0)

class MetricGraph2:
    def __init__(self, h_target=0.02):
        self.h_target = h_target; self.edges = []; self.vertices = {}; self._built = False
    def add_vertex(self, name, delta=0.0):
        self.vertices[name] = dict(delta=delta, incident=[]); return name
    def add_edge(self, vA, vB, L):
        n = max(5, int(round(L / self.h_target)) + 1); h = L / (n - 1); idx = len(self.edges)
        self.edges.append(dict(L=L, n=n, h=h, vA=vA, vB=vB))
        self.vertices[vA]['incident'].append((idx, 'A')); self.vertices[vB]['incident'].append((idx, 'B')); return idx
    def build(self):
        gid = 0; self.vid = {}
        for name in self.vertices: self.vid[name] = gid; gid += 1
        for e in self.edges:
            n = e['n']; e['interior'] = list(range(gid, gid + n - 2)); gid += n - 2
            g = np.empty(n, dtype=int); g[0] = self.vid[e['vA']]; g[-1] = self.vid[e['vB']]; g[1:-1] = e['interior']; e['gmap'] = g
        self.N = gid
        rows, cols, vals = [], [], []
        def add(i, j, v): rows.append(i); cols.append(j); vals.append(v)
        for e in self.edges:                       # interior 3-point Laplacian (uses vertex DOFs at the ends)
            h = e['h']; g = e['gmap']
            for k in range(1, e['n'] - 1):
                add(g[k], g[k], -2.0/h**2); add(g[k], g[k-1], 1.0/h**2); add(g[k], g[k+1], 1.0/h**2)
        self.L = sp.csr_matrix((vals, (rows, cols)), shape=(self.N, self.N))
        rows, cols, vals = [], [], []
        for name, v in self.vertices.items():        # constraint rows: sum of 2nd-order outward derivatives = g q_v
            iv = self.vid[name]; diag = -v['delta']
            for ei, end in v['incident']:
                e = self.edges[ei]; h = e['h']; g = e['gmap']
                n1, n2 = (g[1], g[2]) if end == 'A' else (g[-2], g[-3])
                diag += 3.0/(2*h); add(iv, n1, -4.0/(2*h)); add(iv, n2, 1.0/(2*h))
            add(iv, iv, diag)
        self.C = sp.csr_matrix((vals, (rows, cols)), shape=(self.N, self.N))
        self.is_vertex = np.zeros(self.N, dtype=bool); self.is_vertex[list(self.vid.values())] = True
        self._built = True; return self
    def edge_x(self, ei): e = self.edges[ei]; return np.linspace(0.0, e['L'], e['n'])
    def scatter_edge(self, q, ei, vals): q[self.edges[ei]['gmap']] = vals
    def gather_edge(self, q, ei): return q[self.edges[ei]['gmap']]

class NLSPropagator2:
    def __init__(self, graph, dt):
        assert graph._built; self.G = graph; self.dt = dt
        I = sp.identity(graph.N, format='csr', dtype=complex)
        A = (I - 1j*dt/2*graph.L).tolil(); B = (I + 1j*dt/2*graph.L).tolil()
        for iv in graph.vid.values():
            A[iv, :] = graph.C[iv, :].toarray().ravel(); B[iv, :] = 0.0
        self.lu = spla.splu(A.tocsc()); self.B = B.tocsr()
    def step(self, q):
        q = q*np.exp(2j*np.abs(q)**2*(self.dt/2)); q = self.lu.solve(self.B.dot(q)); return q*np.exp(2j*np.abs(q)**2*(self.dt/2))

def mass(G, q): return sum(np.trapz(np.abs(G.gather_edge(q, ei))**2, dx=e['h']) for ei, e in enumerate(G.edges))
def d_out_4pt(a, h, end):   # 4-point (3rd-order) one-sided OUTWARD derivative at an edge end
    if end == 'A': return -(-11*a[0] + 18*a[1] - 9*a[2] + 2*a[3])/(6*h)
    return (11*a[-1] - 18*a[-2] + 9*a[-3] - 2*a[-4])/(6*h)

if __name__ == "__main__":
    print("="*80); print("GRAPH NLS SOLVER, SECOND-ORDER VERTEX -- CONTROLS", el()); ok = True
    # CTRL-A stationary soliton on a long edge with Neumann ends
    G = MetricGraph2(0.02); G.add_vertex('L'); G.add_vertex('R'); e = G.add_edge('L', 'R', 40.0); G.build()
    x = G.edge_x(e); q = np.zeros(G.N, complex); G.scatter_edge(q, e, soliton_field(x, 1.0, 0.0, 20.0)); m0 = mass(G, q)
    prop = NLSPropagator2(G, 2e-4); q0 = q.copy()
    for k in range(int(2.0/2e-4)): q = prop.step(q)
    dm = abs(mass(G, q)-m0)/m0; shape = np.max(np.abs(np.abs(G.gather_edge(q, e)) - np.abs(G.gather_edge(q0, e))))
    print(f"CTRL-A stationary: mass drift {dm:.2e}, max||q|-|q0|| {shape:.2e}  ->", "PASS" if dm < 1e-6 and shape < 2e-3 else "FAIL"); ok &= dm < 1e-6 and shape < 2e-3
    # CTRL-B moving soliton
    q = np.zeros(G.N, complex); G.scatter_edge(q, e, soliton_field(x, 1.0, -0.5, 12.0)); m0 = mass(G, q)
    for k in range(int(4.0/2e-4)): q = prop.step(q)
    xpk = x[np.argmax(np.abs(G.gather_edge(q, e)))]; env = np.max(np.abs(np.abs(G.gather_edge(q, e)) - np.abs(soliton_field(x, 1.0, -0.5, 12.0, t=4.0))))
    print(f"CTRL-B moving: predicted peak x=20.000, measured {xpk:.3f}; envelope err {env:.2e}; mass drift {abs(mass(G,q)-m0)/m0:.2e}  ->", "PASS" if abs(xpk-20) < 0.05 and env < 2e-2 else "FAIL"); ok &= abs(xpk-20) < 0.05 and env < 2e-2
    # CTRL-D degree-3 Kirchhoff star: fast soliton, reflected mass -> 1/9, transmitted 4/9 each
    def star(g=0.0, v=4.0, h=0.02):
        G = MetricGraph2(h); [G.add_vertex(n) for n in ('E0', 'V', 'E1', 'E2')]; G.vertices['V']['delta'] = g
        e0 = G.add_edge('E0', 'V', 30.0); e1 = G.add_edge('V', 'E1', 30.0); e2 = G.add_edge('V', 'E2', 30.0); G.build()
        q = np.zeros(G.N, complex); G.scatter_edge(q, e0, soliton_field(G.edge_x(e0), 1.0, -v/4, 15.0)); m0 = mass(G, q)
        prop = NLSPropagator2(G, 1e-4); T = (15.0 + 8.0)/v
        for k in range(int(T/1e-4)): q = prop.step(q)
        me = [np.trapz(np.abs(G.gather_edge(q, ei))**2, dx=G.edges[ei]['h'])/m0 for ei in (e0, e1, e2)]
        return me, abs(mass(G, q)-m0)/m0
    (R, T1, T2), dm = star()
    # the linear limit is R = 1/9; a soliton of amplitude 2 at v = 4 reflects less (nonlinear correction). The lumped scheme
    # (pde_solver.py) gives R = 0.07705 at h = 0.02 and 0.07703 at h = 0.04 (solver2_nonlinear_star_test.py): require agreement.
    print(f"CTRL-D degree-3 Kirchhoff star, soliton v=4: R={R:.4f} (lumped scheme 0.0770; linear limit 1/9={1/9:.4f}), T1={T1:.4f}, T2={T2:.4f}; mass drift {dm:.1e}  ->", "PASS" if abs(R-0.0770) < 2e-3 else "FAIL"); ok &= abs(R-0.0770) < 2e-3
    # CTRL-C delta vertex on a line (degree 2): transmission ~ v^2/(v^2+g^2) trend (HMZ)
    def line_delta(g, v):
        G = MetricGraph2(0.02); [G.add_vertex(n) for n in ('E0', 'V', 'E1')]; G.vertices['V']['delta'] = g
        e0 = G.add_edge('E0', 'V', 30.0); e1 = G.add_edge('V', 'E1', 30.0); G.build()
        q = np.zeros(G.N, complex); G.scatter_edge(q, e0, soliton_field(G.edge_x(e0), 1.0, -v/4, 15.0)); m0 = mass(G, q)
        prop = NLSPropagator2(G, 1e-4); T = (15.0 + 8.0)/v
        for k in range(int(T/1e-4)): q = prop.step(q)
        return np.trapz(np.abs(G.gather_edge(q, e1))**2, dx=G.edges[e1]['h'])/m0
    Tg0 = line_delta(0.0, 4.0); T3v4 = line_delta(3.0, 4.0); T3v10 = line_delta(3.0, 10.0)
    print(f"CTRL-C delta vertex: g=0 T={Tg0:.4f} (expect 1); g=3: v=4 T={T3v4:.3f} (HMZ 16/25={16/25:.3f}), v=10 T={T3v10:.3f} (HMZ 100/109={100/109:.3f})  ->", "PASS" if abs(Tg0-1) < 1e-3 and T3v10 > T3v4 else "FAIL"); ok &= abs(Tg0-1) < 1e-3 and T3v10 > T3v4
    # CTRL-K discrete Kirchhoff residual at the degree-3 vertex with an INDEPENDENT 4-point outward-derivative formula
    for h in (0.02, 0.01):
        G = MetricGraph2(h); G.add_vertex('A'); G.add_vertex('B'); E = [G.add_edge('A', 'B', L) for L in (6.0, 10.0, 8.0)]; G.build()
        q = np.zeros(G.N, complex); G.scatter_edge(q, E[1], soliton_field(G.edge_x(E[1]), 0.8, -0.5, 5.0)); m0 = mass(G, q)
        dt = h/100; prop = NLSPropagator2(G, dt); res = []
        for k in range(1, int(4.0/dt)+1):
            q = prop.step(q)
            if k % int(0.05/dt) == 0 and k*dt > 2.0:
                d = [d_out_4pt(G.gather_edge(q, ei), G.edges[ei]['h'], 'B') for ei in E]
                res.append(abs(sum(d))/max(abs(x) for x in d))
        print(f"CTRL-K h={h}: discrete Kirchhoff residual at B (4-pt formula, t in [2,4]): median {np.median(res):.2e}, max {np.max(res):.2e}; mass drift {abs(mass(G,q)-m0)/m0:.1e}")
    print("OVERALL:", "ALL PASS" if ok else "SOME FAIL", el())
