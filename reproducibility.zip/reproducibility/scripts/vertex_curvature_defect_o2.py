"""Defect law check with the SECOND-ORDER vertex solver (pde_solver2): 4-point germ derivatives, sampling 0.002,
4th-order time differencing.  Usage: python3 -u vertex_curvature_defect_o2.py <kind: theta|ring> <h> <dt>"""
import sys, os, time, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import pde_solver as P, pde_solver2 as P2
inv = np.linalg.inv; t0 = time.time(); lam = 0.6
kind, h, dt = sys.argv[1], float(sys.argv[2]), float(sys.argv[3]); T_end = 6.0; sample = 0.002
def Vmat(q, qx):
    return np.array([[-2j*lam**2 + 1j*abs(q)**2, 2*lam*q + 1j*qx], [-2*lam*np.conj(q) + 1j*np.conj(qx), 2j*lam**2 - 1j*abs(q)**2]])
def transfer(qarr, hh):
    T = np.eye(2, dtype=complex)
    for qq in qarr:
        w = np.sqrt(lam**2 + abs(qq)**2); U = np.array([[-1j*lam, qq], [-np.conj(qq), 1j*lam]])
        T = (np.cos(w*hh)*np.eye(2) + (np.sin(w*hh)/w)*U) @ T
    return T
def mid(a): return 0.5*(a[1:] + a[:-1])
def dstart(a, hh): return (-11*a[0] + 18*a[1] - 9*a[2] + 2*a[3])/(6*hh)          # d/dx at x=0 in the edge coordinate (4-point)
def dend(a, hh):   return (11*a[-1] - 18*a[-2] + 9*a[-3] - 2*a[-4])/(6*hh)        # d/dx at x=L
def d4(y, dx):     # 4th-order central differences, 2nd-order at the ends
    d = np.gradient(y, dx); d[2:-2] = (-y[4:] + 8*y[3:-1] - 8*y[1:-3] + y[:-4])/(12*dx); return d
G = P2.MetricGraph2(h_target=h); G.add_vertex('A'); G.add_vertex('B')
E = [G.add_edge('A', 'B', 6.0), G.add_edge('A', 'B', 10.0)] + ([G.add_edge('A', 'B', 8.0)] if kind == 'theta' else [])
G.build(); hs = [G.edges[e]['h'] for e in E]
q = np.zeros(G.N, complex); G.scatter_edge(q, E[1], P.soliton_field(G.edge_x(E[1]), 0.8, -0.5, 5.0)); m0 = P2.mass(G, q)
prop = P2.NLSPropagator2(G, dt); every = int(round(sample/dt)); rows = []
def rec(t):
    a1 = G.gather_edge(q, E[0]); a2 = G.gather_edge(q, E[1])
    T1 = transfer(mid(a1), hs[0]); T2 = transfer(mid(a2), hs[1]); T2r = transfer(mid(a2)[::-1], hs[1])
    if kind == 'ring':
        rows.append((t, np.trace(T1 @ inv(T2)).real, np.trace(T2r @ T1).real))
    else:
        a3 = G.gather_edge(q, E[2]); T3 = transfer(mid(a3), hs[2]); H_A = T2r @ T1; H_B = T1 @ T2r
        F_A = Vmat(a2[0], -dstart(a2, hs[1])) - Vmat(a1[0], dstart(a1, hs[0]))
        F_B = Vmat(a1[-1], dend(a1, hs[0])) - Vmat(a2[-1], -dend(a2, hs[1]))
        rhs = (np.trace(H_A @ F_A) + np.trace(H_B @ F_B)).real
        q3x = dend(a3, hs[2]); F_pred = -1j*np.array([[0, q3x], [np.conj(q3x), 0]])
        leak = np.linalg.norm(F_B - F_pred)/max(np.linalg.norm(F_B), 1e-30)
        dB = [dend(a1, hs[0]), dend(a2, hs[1]), dend(a3, hs[2])]; kir = abs(sum(dB))/max(abs(x) for x in dB)
        rows.append((t, np.trace(H_A).real, rhs, leak, kir, abs(np.trace(H_A @ T2r @ T3 @ inv(H_A) @ inv(T2r @ T3)) - 2)))
rec(0.0)
for k in range(1, int(round(T_end/dt))+1):
    q = prop.step(q)
    if k % every == 0: rec(k*dt)
R = np.array(rows); ts = R[:, 0]; out = dict(kind=kind, h=h, dt=dt, mass_drift=float(abs(P2.mass(G, q)-m0)/m0))
if kind == 'ring':
    out.update(drift_edge_convention=float(np.max(np.abs(R[:,1]-R[0,1]))), drift_true_monodromy=float(np.max(np.abs(R[:,2]-R[0,2]))))
    print(f"RING h={h} dt={dt}: edge-convention drift {out['drift_edge_convention']:.3e}, true monodromy drift {out['drift_true_monodromy']:.3e}, mass drift {out['mass_drift']:.1e}")
else:
    trH, rhs, leak, kir, kc = R[:,1], R[:,2], R[:,3], R[:,4], R[:,5]
    dtr = d4(trH, ts[1]-ts[0]); cum = np.concatenate([[0], np.cumsum(0.5*(rhs[1:]+rhs[:-1])*np.diff(ts))])
    act = np.abs(rhs) > 0.02*np.max(np.abs(rhs))
    out.update(pointwise_rel_err=float(np.max(np.abs(dtr-rhs))/np.max(np.abs(dtr))), pointwise_rel_err_active_median=float(np.median(np.abs(dtr-rhs)[act])/np.max(np.abs(dtr))),
               peak_rate=float(np.max(np.abs(dtr))), cumulative_rhs=float(cum[-1]), actual_drift=float(trH[-1]-trH[0]),
               leak_identity_median=float(np.median(leak[act])), leak_identity_max=float(np.max(leak[act])), kirchhoff_residual_median=float(np.median(kir[act])), kappa_max=float(kc.max()))
    print(f"THETA h={h} dt={dt}: pointwise max rel err {out['pointwise_rel_err']:.2e} (median over active window {out['pointwise_rel_err_active_median']:.2e}); "
          f"cumulative {out['cumulative_rhs']:+.5f} vs actual {out['actual_drift']:+.5f}; flux identity dev median {out['leak_identity_median']:.2e} max {out['leak_identity_max']:.2e}; "
          f"Kirchhoff residual median {out['kirchhoff_residual_median']:.2e}; kappa max {out['kappa_max']:.3f}; mass drift {out['mass_drift']:.1e}")
json.dump(out, open(os.path.join(HERE, "..", "data", f"vcd_o2_{kind}_h{h}.json"), "w"), indent=1)
np.save(os.path.join(HERE, "..", "data", f"vcd_o2_{kind}_h{h}.npy"), R)
print(f"[{time.time()-t0:.0f}s] done")
