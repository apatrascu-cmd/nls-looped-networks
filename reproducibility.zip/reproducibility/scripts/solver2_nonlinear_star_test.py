"""NONLINEAR soliton (v=4) on the degree-3 Kirchhoff star: reflected/transmitted mass for both schemes at h=0.04, 0.02 (dt ~ h^2)."""
import sys, numpy as np, time
import pde_solver as P, pde_solver2 as P2
t0 = time.time(); log = lambda *a: (print(*a), sys.stdout.flush())
def star_nl(scheme, h, dt, v=4.0):
    G = (P.MetricGraph if scheme == 1 else P2.MetricGraph2)(h_target=h)
    for n in ('E0', 'V', 'E1', 'E2'): G.add_vertex(n)
    E = [G.add_edge('E0', 'V', 30.0), G.add_edge('V', 'E1', 30.0), G.add_edge('V', 'E2', 30.0)]; G.build()
    q = np.zeros(G.N, complex); G.scatter_edge(q, E[0], P.soliton_field(G.edge_x(E[0]), 1.0, -v/4, 15.0))
    m = lambda q: sum(np.trapz(np.abs(G.gather_edge(q, ei))**2, dx=G.edges[ei]['h']) for ei in E); m0 = m(q)
    prop = (P.NLSPropagator(G, dt=dt) if scheme == 1 else P2.NLSPropagator2(G, dt)); T = (15.0 + 8.0)/v
    for kk in range(int(T/dt)): q = prop.step(q)
    return [np.trapz(np.abs(G.gather_edge(q, ei))**2, dx=G.edges[ei]['h'])/m0 for ei in E], abs(m(q)-m0)/m0
log("NONLINEAR soliton star (amplitude 2, v=4), degree-3 Kirchhoff; linear limit R=1/9=0.1111, T=4/9=0.4444")
for h, dt in ((0.04, 4e-4), (0.02, 1e-4)):
    for scheme in (1, 2):
        fr, dm = star_nl(scheme, h, dt)
        log(f"  scheme {scheme} ({'lumped' if scheme==1 else 'constraint'}) h={h} dt={dt}: R={fr[0]:.5f} T1={fr[1]:.5f} T2={fr[2]:.5f}  mass drift {dm:.1e}   [{time.time()-t0:.0f}s]")
