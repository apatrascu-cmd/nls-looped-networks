"""Schematic figure for main_v2.tex (Fig. 1). Symbols and short tags only; explanations live in the caption.
(a) theta graph, edge coordinates A->B, the two directed loops, the soliton datum.  (b) vertex B as seen by gamma_1."""
import os, numpy as np, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Circle
HERE = os.path.dirname(os.path.abspath(__file__)); FIG = os.path.abspath(os.path.join(HERE, "..", "figures"))
BLUE, ORANGE, AQUA, INK, MUTED = "#2a78d6", "#eb6834", "#1baf7a", "#0b0b0b", "#52514e"
plt.rcParams.update({"font.size": 9, "mathtext.fontset": "dejavusans"})
fig, (a, b) = plt.subplots(1, 2, figsize=(7.2, 3.6), gridspec_kw=dict(width_ratios=[1.25, 1.0]))
for ax in (a, b): ax.set_aspect("equal"); ax.axis("off")
def head(ax, xy, dxy, color, lw=1.4, ls="-"):
    ax.annotate("", xytext=xy, xy=(xy[0]+dxy[0], xy[1]+dxy[1]), arrowprops=dict(arrowstyle="-|>", color=color, lw=lw, shrinkA=0, shrinkB=0, linestyle=ls))

# ---------------- (a) theta graph
A, B = (0.0, 0.0), (4.0, 0.0)
for rad, col in ((-0.45, BLUE), (0.0, ORANGE), (0.45, AQUA)):
    a.add_patch(FancyArrowPatch(A, B, connectionstyle=f"arc3,rad={rad}", arrowstyle="-", color=col, lw=2.0, shrinkA=6, shrinkB=6))
head(a, (2.15, 0.90), (0.30, 0.0), BLUE); head(a, (2.85, 0.0), (0.30, 0.0), ORANGE); head(a, (2.15, -0.90), (0.30, 0.0), AQUA)
a.text(2.0, 1.08, r"$e_1$   ($\ell_1=6$)", color=BLUE, ha="center", va="bottom", fontsize=9)
a.text(3.0, 0.12, r"$e_2$   ($\ell_2=10$)", color=ORANGE, ha="center", va="bottom", fontsize=9)
a.text(2.0, -1.08, r"$e_3$   ($\ell_3=8$)", color=AQUA, ha="center", va="top", fontsize=9)
xs = np.linspace(1.05, 2.15, 140); a.plot(xs, 0.42/np.cosh(6*(xs-1.6)), color=ORANGE, lw=1.2)
head(a, (1.88, 0.30), (0.30, 0.0), INK, lw=1.0)
a.text(1.6, -0.16, "soliton, $v=2$", ha="center", va="top", fontsize=8, color=INK)
for p, name, dx in ((A, "A", -0.25), (B, "B", 0.25)):
    a.add_patch(Circle(p, 0.09, color=INK, zorder=5)); a.text(p[0]+dx, p[1], name, ha="center", va="center", fontsize=11, weight="bold")
a.add_patch(FancyArrowPatch((0.45, 1.45), (3.55, 1.45), connectionstyle="arc3,rad=-0.25", arrowstyle="-|>", color=MUTED, lw=1.1, mutation_scale=11))
a.add_patch(FancyArrowPatch((3.55, -1.45), (0.45, -1.45), connectionstyle="arc3,rad=-0.25", arrowstyle="-|>", color=MUTED, lw=1.1, mutation_scale=11, linestyle=(0, (4, 3))))
a.text(2.0, 1.92, r"$\gamma_1 = e_1\, e_2^{\leftarrow}$", ha="center", va="bottom", fontsize=9.5, color=INK)
a.text(2.0, -1.92, r"$\gamma_2 = e_3\, e_2^{\leftarrow}$", ha="center", va="top", fontsize=9.5, color=INK)
a.text(2.0, -2.32, r"$e_2^{\leftarrow}$: $e_2$ traversed $B\to A$", ha="center", va="top", fontsize=8, color=MUTED)
a.set_xlim(-0.6, 4.6); a.set_ylim(-2.75, 2.45)
a.set_title(r"(a) theta graph; edge coordinates run $A\to B$", fontsize=9, loc="left")

# ---------------- (b) vertex B as seen by gamma_1
Bz = (0.0, 0.0)
def seg(ax, p, q, color): ax.plot([p[0], q[0]], [p[1], q[1]], color=color, lw=2.2, solid_capstyle="round")
seg(b, (-1.4, 1.1), Bz, BLUE); seg(b, (-1.6, 0.0), Bz, ORANGE); seg(b, (-1.4, -1.1), Bz, AQUA)
b.add_patch(Circle(Bz, 0.08, color=INK, zorder=5)); b.text(0.24, 0.0, "B", ha="center", va="center", fontsize=11, weight="bold")
head(b, (-1.05, 0.825), (0.35, -0.275), BLUE)                 # arriving along e1
head(b, (-0.70, 0.0), (-0.40, 0.0), ORANGE)                   # departing along e2 reversed
head(b, (-0.55, -0.43), (-0.40, -0.315), AQUA, lw=1.1, ls=(0, (3, 2)))   # leakage into e3
b.text(-1.55, 1.1, "$e_1$  in\n$V^{\\rm in}(B)$", color=BLUE, ha="right", va="center", fontsize=8.5, linespacing=1.15)
b.text(-1.75, 0.0, "$e_2^{\\leftarrow}$  out\n$V^{\\rm out}(B)$", color=ORANGE, ha="right", va="center", fontsize=8.5, linespacing=1.15)
b.text(-1.55, -1.1, "$e_3$  off-loop\nderivative $\\partial_3 q$", color=AQUA, ha="right", va="center", fontsize=8.5, linespacing=1.15)
b.text(0.55, 0.85, r"$F_B = V^{\rm in}(B)-V^{\rm out}(B)$", fontsize=9, color=INK, ha="left", va="center")
b.text(0.55, 0.42, r"$(F_B)_{12}=\mathrm{i}\,\partial_3q$", fontsize=8.5, color=MUTED, ha="left", va="center")
b.text(0.55, 0.08, r"$(F_B)_{21}=\mathrm{i}\,\overline{\partial_3q}$", fontsize=8.5, color=MUTED, ha="left", va="center")
b.text(0.55, -0.45, r"$D_B = W_{e_2^{\leftarrow}}\, W_{e_1}^{-1}$", fontsize=9, color=INK, ha="left", va="center")
b.text(0.55, -0.85, r"$\partial_t W_g = V_g(B,t)\,W_g$", fontsize=8, color=MUTED, ha="left", va="center")
b.set_xlim(-3.25, 4.15); b.set_ylim(-1.95, 1.95)
b.set_title(r"(b) vertex $B$ as seen by $\gamma_1$", fontsize=9, loc="left")
fig.tight_layout(w_pad=0.5); fig.savefig(f"{FIG}/v2_fig0_schematic.pdf"); fig.savefig(f"{FIG}/v2_fig0_schematic.png", dpi=170); print("saved schematic")
