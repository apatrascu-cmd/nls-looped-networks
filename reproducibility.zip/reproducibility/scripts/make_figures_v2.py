"""Figures for the rebuilt manuscript (main_v2.tex). Deterministic reruns of the verified computations; saves
PDF (for LaTeX) + PNG (for inspection) in ../figures/ and the plotted numbers in ../data/v2_numbers_part{1,2}.json.
Palette: reference categorical slots 1-3 (blue #2a78d6, orange #eb6834, aqua #1baf7a), <=3 series per panel,
legend + direct end labels, thin lines, recessive grid, single y-axis per panel.
"""
import sys, os, json, time, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
FIG = os.path.abspath(os.path.join(HERE, "..", "figures")); DATA = os.path.abspath(os.path.join(HERE, "..", "data"))
import pde_solver as P, pde_solver2 as P2
inv = np.linalg.inv; t0 = time.time()
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                     "grid.alpha": 0.25, "grid.linewidth": 0.6, "legend.frameon": False, "figure.dpi": 100})
part = int(sys.argv[sys.argv.index("--part")+1]) if "--part" in sys.argv else 1
lam = 0.6

def Vmat(q, qx, lam=lam):
    return np.array([[-2j*lam**2 + 1j*abs(q)**2, 2*lam*q + 1j*qx], [-2*lam*np.conj(q) + 1j*np.conj(qx), 2j*lam**2 - 1j*abs(q)**2]])
def expm2(M):
    s = np.sqrt(-np.linalg.det(M) + 0j)
    return np.eye(2) + M if abs(s) < 1e-13 else np.cosh(s)*np.eye(2) + (np.sinh(s)/s)*M
def transfer(qarr, h, lam=lam, beta=2.0):
    T = np.eye(2, dtype=complex)
    for qq in qarr:
        U = np.array([[-1j*lam, qq], [-(beta/2)*np.conj(qq), 1j*lam]]); w = np.sqrt(lam**2 + (beta/2)*abs(qq)**2)
        T = (np.cos(w*h)*np.eye(2) + (np.sin(w*h)/w)*U) @ T
    return T
def mid(a): return 0.5*(a[1:] + a[:-1])
def dq_start(a, h): return (-11*a[0] + 18*a[1] - 9*a[2] + 2*a[3])/(6*h)   # 4-point one-sided
def dq_end(a, h):   return (11*a[-1] - 18*a[-2] + 9*a[-3] - 2*a[-4])/(6*h)
def kap(X, Y): return np.trace(X @ Y @ inv(X) @ inv(Y)) - 2
def endlabel(ax, x, y, text, color, dy=0):
    ax.annotate(text, (x[-1], y[-1]), xytext=(4, dy), textcoords="offset points", color=color, fontsize=8, va="center")
def save(fig, name):
    fig.tight_layout(); fig.savefig(f"{FIG}/{name}.pdf"); fig.savefig(f"{FIG}/{name}.png", dpi=160); plt.close(fig); print(f"  saved {name}")

def build(kind, h):
    G = P2.MetricGraph2(h_target=h); G.add_vertex('A'); G.add_vertex('B')
    E = [G.add_edge('A', 'B', 6.0), G.add_edge('A', 'B', 10.0)] + ([G.add_edge('A', 'B', 8.0)] if kind == 'theta' else [])
    G.build(); q = np.zeros(G.N, dtype=complex); G.scatter_edge(q, E[1], P.soliton_field(G.edge_x(E[1]), 0.8, -0.5, 5.0))
    return G, E, [G.edges[e]['h'] for e in E], q

numbers = {}
if part == 1:
    # ---------- Fig 1: ring, edge-convention trace vs true monodromy
    G, E, hs, q = build('ring', 0.02); dt = 2e-4; prop = P2.NLSPropagator2(G, dt); every = 100
    ts, trP, trC = [], [], []
    def rec(t):
        q1 = mid(G.gather_edge(q, E[0])); q2 = mid(G.gather_edge(q, E[1]))
        T1 = transfer(q1, hs[0]); T2 = transfer(q2, hs[1]); T2r = transfer(q2[::-1], hs[1])
        ts.append(t); trP.append(np.trace(T1 @ inv(T2)).real); trC.append(np.trace(T2r @ T1).real)
    rec(0.0)
    for k in range(1, int(round(6.0/dt))+1):
        q = prop.step(q)
        if k % every == 0: rec(k*dt)
    ts, trP, trC = map(np.array, (ts, trP, trC))
    numbers["ring"] = dict(drift_edge_convention=float(np.max(np.abs(trP - trP[0]))), drift_true_monodromy=float(np.max(np.abs(trC - trC[0]))),
                           tr_true=float(trC[0]), tr_edge_t0=float(trP[0]), tr_edge_min=float(trP.min()), tr_edge_max=float(trP.max()))
    fig, ax = plt.subplots(figsize=(5.4, 3.0))
    ax.plot(ts, trC, color=BLUE, lw=1.6, label=r"$\mathrm{tr}(T_2^{\leftarrow}T_1)$: consistently oriented monodromy")
    ax.plot(ts, trP, color=ORANGE, lw=1.6, label=r"$\mathrm{tr}(T_1T_2^{-1})$: edge-convention loop product")
    endlabel(ax, ts, trC, "conserved", BLUE, 6); endlabel(ax, ts, trP, "drifts", ORANGE, -6)
    ax.set_xlabel(r"$t$"); ax.set_ylabel("loop trace"); ax.set_xlim(0, 6.9); ax.legend(loc="lower left", fontsize=7.5)
    save(fig, "v2_fig1_ring"); print(f"[{time.time()-t0:5.1f}s] fig1 done", numbers["ring"])

    # ---------- Fig 2: theta defect law (rates and cumulative)
    G, E, hs, q = build('theta', 0.02); dt = 2e-4; prop = P2.NLSPropagator2(G, dt); every = 20   # sample 0.004
    ts, trH, rhs, kc, kp = [], [], [], [], []
    def rec(t):
        a1 = G.gather_edge(q, E[0]); a2 = G.gather_edge(q, E[1]); a3 = G.gather_edge(q, E[2])
        T1 = transfer(mid(a1), hs[0]); T2 = transfer(mid(a2), hs[1]); T3 = transfer(mid(a3), hs[2]); T2r = transfer(mid(a2)[::-1], hs[1])
        H_A = T2r @ T1; H_B = T1 @ T2r
        F_A = Vmat(a2[0], -dq_start(a2, hs[1])) - Vmat(a1[0], dq_start(a1, hs[0]))      # arrive along e2 reversed, depart along e1
        F_B = Vmat(a1[-1], dq_end(a1, hs[0])) - Vmat(a2[-1], -dq_end(a2, hs[1]))         # arrive along e1, depart along e2 reversed
        ts.append(t); trH.append(np.trace(H_A).real); rhs.append((np.trace(H_A @ F_A) + np.trace(H_B @ F_B)).real)
        kc.append(abs(kap(H_A, T2r @ T3))); kp.append(abs(kap(T1 @ inv(T2), T2 @ inv(T3))))
    rec(0.0)
    for k in range(1, int(round(6.0/dt))+1):
        q = prop.step(q)
        if k % every == 0: rec(k*dt)
    ts, trH, rhs, kc, kp = map(np.array, (ts, trH, rhs, kc, kp))
    dtr = np.gradient(trH, ts); cum = np.concatenate([[0], np.cumsum(0.5*(rhs[1:]+rhs[:-1])*np.diff(ts))])
    numbers["theta_defect_law"] = dict(pointwise_rel_err=float(np.max(np.abs(dtr - rhs))/np.max(np.abs(dtr))), peak_rate=float(np.max(np.abs(dtr))),
                                       cumulative_rhs=float(cum[-1]), actual_drift=float(trH[-1]-trH[0]), kappa_consistent_max=float(kc.max()), kappa_edgeconv_max=float(kp.max()))
    fig, (a, b) = plt.subplots(1, 2, figsize=(7.2, 3.0))
    a.plot(ts, dtr, color=BLUE, lw=1.6, label=r"$\frac{d}{dt}\,\mathrm{tr}\,H_{\gamma_1}$ (from the evolving field)")
    a.plot(ts, rhs, color=ORANGE, lw=1.4, ls="--", label=r"$\sum_v \mathrm{tr}(H^{(v)}_{\gamma_1}F_v)$ (vertex curvature)")
    a.set_xlabel(r"$t$"); a.set_ylabel("rate"); a.legend(loc="lower left", fontsize=7); a.set_title("(a) defect law, pointwise", fontsize=9, loc="left")
    b.plot(ts, trH - trH[0], color=BLUE, lw=1.6, label=r"$\mathrm{tr}\,H_{\gamma_1}(t)-\mathrm{tr}\,H_{\gamma_1}(0)$")
    b.plot(ts, cum, color=ORANGE, lw=1.4, ls="--", label=r"$\int_0^t \sum_v \mathrm{tr}(H^{(v)}F_v)\,dt'$")
    b.set_xlabel(r"$t$"); b.set_ylabel("cumulative change"); b.legend(loc="upper right", fontsize=7); b.set_title("(b) integrated", fontsize=9, loc="left")
    save(fig, "v2_fig2_defect_law"); print(f"[{time.time()-t0:5.1f}s] fig2 done", numbers["theta_defect_law"])

    # ---------- Fig 4: Sobirov transparent theta under the two gluings
    beta0 = 2.0; betas = [3.0, 4.0, 12.0]; l = 1.3
    def D(beta): d = (beta0/beta)**0.25; return np.diag([d, 1/d])
    lams = np.linspace(0.2, 2.5, 24); N = 3000; h = l/N; xs = (np.arange(N)+0.5)*h
    fields = {"Stokes wave $f=0.9+0.3i$": np.full(N, 0.9+0.3j), r"soliton $f=1.6\,\mathrm{sech}(1.6(x-0.6))e^{-ix}$": 1.6/np.cosh(1.6*(xs-0.6))*np.exp(-1j*xs)}
    res = {}
    for name, f in fields.items():
        kV1, kD = [], []
        for lm in lams:
            Ts = [transfer(np.sqrt(beta0/b)*f, h, lam=lm, beta=b) for b in betas]
            H1 = Ts[0] @ inv(Ts[1]); H2 = Ts[1] @ inv(Ts[2]); kV1.append(abs(kap(H1, H2)))
            D1, D2, D3 = (D(b) for b in betas)
            H1g = D1 @ inv(D2) @ inv(Ts[1]) @ D2 @ inv(D1) @ Ts[0]; H2g = D2 @ inv(D3) @ inv(Ts[2]) @ D3 @ inv(D2) @ Ts[1]; kD.append(abs(kap(H1g, H2g)))
        res[name] = (np.array(kV1), np.array(kD))
    numbers["sobirov"] = {k: dict(kappa_V1_max=float(v[0].max()), kappa_V1_min=float(v[0].min()), kappa_induced_max=float(v[1].max())) for k, v in res.items()}
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.0), sharey=True)
    for ax, (name, (kV1, kD)) in zip(axs, res.items()):
        ax.semilogy(lams, np.maximum(kV1, 1e-17), color=ORANGE, lw=1.6, marker="o", ms=3, label=r"$\psi$-continuity gluing $V_v=\mathbf{1}$")
        ax.semilogy(lams, np.maximum(kD, 1e-17), color=BLUE, lw=1.6, marker="s", ms=3, label=r"induced gluing $D_{e'}D_e^{-1}$")
        ax.set_xlabel(r"$\lambda$ (real)"); ax.set_title(name, fontsize=8.5, loc="left"); ax.set_ylim(1e-17, 1e-1)
    axs[0].set_ylabel(r"$|\kappa(\lambda)|$"); axs[0].legend(loc="center left", fontsize=7)
    save(fig, "v2_fig4_sobirov"); print(f"[{time.time()-t0:5.1f}s] fig4 done", numbers["sobirov"])
    json.dump(numbers, open(f"{DATA}/v2_numbers_part1.json", "w"), indent=1)

if part == 2:
    # ---------- Fig 3: dressed (categorical) vs undressed loop data on the theta
    G, E, hs, q = build('theta', 0.02); dt = 2e-4; prop = P2.NLSPropagator2(G, dt); every = 100
    def germV(qv, vertex, e, orient):
        arr = G.gather_edge(qv, E[e]); h = hs[e]
        return Vmat(arr[0], orient*dq_start(arr, h)) if vertex == 'A' else Vmat(arr[-1], orient*dq_end(arr, h))
    germs = [(v, e, o) for v in ('A', 'B') for e in (0, 1, 2) for o in (+1, -1)]
    W = {g: np.eye(2, dtype=complex) for g in germs}; Vprev = {g: germV(q, *g) for g in germs}
    g1f, g1r, g2f, g2r, g3f, g3r = (0, 1), (0, -1), (1, 1), (1, -1), (2, 1), (2, -1)
    def transfers(qv):
        T = {}
        for e in (0, 1, 2):
            arr = mid(G.gather_edge(qv, E[e])); T[(e, +1)] = transfer(arr, hs[e]); T[(e, -1)] = transfer(arr[::-1], hs[e])
        return T
    def dressed(T):
        Dm = lambda v, i, j: W[(v,)+i] @ inv(W[(v,)+j])
        T1 = Dm('A', g1f, g2r) @ T[g2r] @ Dm('B', g2r, g1f) @ T[g1f]; T2 = Dm('A', g3f, g2r) @ T[g2r] @ Dm('B', g2r, g3f) @ T[g3f]
        T1p = Dm('A', g2f, g1r) @ T[g1r] @ Dm('B', g1r, g2f) @ T[g2f]; T2p = Dm('A', g2f, g3r) @ T[g3r] @ Dm('B', g3r, g2f) @ T[g2f]
        return T1, T2, T1p, T2p
    ts, trD, trU, kcp, kc, ku = [], [], [], [], [], []
    def rec(t):
        T = transfers(q); T1, T2, T1p, T2p = dressed(T); H1c = T[g2r] @ T[g1f]; H2c = T[g2r] @ T[g3f]
        ts.append(t); trD.append(np.trace(T1).real); trU.append(np.trace(H1c).real); kcp.append(kap(T1p, T2p).real); kc.append(kap(T1, T2).real); ku.append(kap(H1c, H2c).real)
    rec(0.0)
    for k in range(1, int(round(6.0/dt))+1):
        q = prop.step(q); Vnow = {g: germV(q, *g) for g in germs}
        for g in germs: W[g] = expm2(dt*0.5*(Vprev[g] + Vnow[g])) @ W[g]
        Vprev = Vnow
        if k % every == 0: rec(k*dt)
    ts, trD, trU, kcp, kc, ku = map(np.array, (ts, trD, trU, kcp, kc, ku))
    numbers["dressed"] = dict(dressed_trace_drift=float(np.max(np.abs(trD-trD[0]))), undressed_trace_drift=float(np.max(np.abs(trU-trU[0]))),
                              kappa_cat_common_germ_drift=float(np.max(np.abs(kcp-kcp[0]))), kappa_cat_different_germs_drift=float(np.max(np.abs(kc-kc[0]))),
                              kappa_undressed_drift=float(np.max(np.abs(ku-ku[0]))))
    fig, (a, b) = plt.subplots(1, 2, figsize=(7.2, 3.0))
    a.plot(ts, trD, color=BLUE, lw=1.6, label=r"dressed $\mathrm{tr}\,\mathcal{T}_{\gamma_1}$"); a.plot(ts, trU, color=ORANGE, lw=1.6, label=r"undressed $\mathrm{tr}\,H_{\gamma_1}$")
    endlabel(a, ts, trD, "dressed", BLUE, 6); endlabel(a, ts, trU, "undressed", ORANGE, -6)
    a.set_xlabel(r"$t$"); a.set_ylabel("loop trace"); a.set_xlim(0, 7.0); a.legend(loc="lower left", fontsize=7); a.set_title("(a) traces of the loop $e_1e_2^{\\leftarrow}$", fontsize=9, loc="left")
    b.plot(ts, kcp, color=BLUE, lw=1.6, label=r"dressed $\hat\kappa$, common departure germ")
    b.plot(ts, kc, color=AQUA, lw=1.6, label=r"dressed $\hat\kappa$, different departure germs")
    b.plot(ts, ku, color=ORANGE, lw=1.6, label=r"undressed $\kappa$")
    b.set_xlabel(r"$t$"); b.set_ylabel(r"$\mathrm{tr}[\,\cdot\,,\cdot\,]-2$"); b.legend(loc="lower left", fontsize=7); b.set_title("(b) commutator invariants", fontsize=9, loc="left")
    save(fig, "v2_fig3_dressed"); print(f"[{time.time()-t0:5.1f}s] fig3 done", numbers["dressed"])
    json.dump(numbers, open(f"{DATA}/v2_numbers_part2.json", "w"), indent=1)
print(f"[{time.time()-t0:5.1f}s] part {part} done")
