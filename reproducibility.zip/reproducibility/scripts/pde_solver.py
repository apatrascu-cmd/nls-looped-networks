#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
Graph NLS PDE solver  (foundation for the soliton-routing correlation study).

Focusing NLS on a metric graph:   i q_t + q_xx + 2|q|^2 q = 0   on each edge,
joined at vertices by linear matching (Kirchhoff / delta) conditions.

Method (research Q4: split-step Fourier is awkward on graphs because the per-edge
FFT assumes periodicity and cannot see the non-local vertex coupling; the graph-
propagation literature, Sobirov et al. PRE 81 066602, uses finite differences with
a junction stencil + a norm-conserving propagator). We use:

  * SPACE: 2nd-order finite differences. The whole graph is one state vector
    (all edge grids concatenated). The discrete graph Laplacian D2 is a single
    sparse SYMMETRIC matrix; vertex rows encode continuity + current balance
    (Kirchhoff), which makes D2 self-adjoint -> the linear flow is unitary.
  * TIME: Strang splitting.  Nonlinear half-step is the EXACT pointwise phase
    rotation q -> q*exp(2i|q|^2 * dt/2)  (|q| is invariant under the pure
    nonlinear flow).  Linear full-step is Crank-Nicolson (Cayley transform of the
    anti-Hermitian generator i*D2): (I - i dt/2 D2) q+ = (I + i dt/2 D2) q  --
    unitary, hence norm-conserving, and it carries the vertex conditions through D2.

This module is a reusable library + a self-test (__main__) of the foundational
CONTROLS (memory rule: a gate needs a known-true control):
   CTRL-A  stationary soliton 2 sech(2x) e^{4it}: |q| time-invariant, mass+energy
           conserved (the cleanest known-true: an exact standing soliton).
   CTRL-B  moving soliton translates rigidly at the analytic velocity, shape and
           mass preserved (validates the moving-frame dynamics).
   CTRL-C  fast soliton across a single delta-vertex (degree-2 = line with a point
           defect of strength g): transmitted mass fraction -> v^2/(v^2+g^2)
           (Holmer-Marzuola-Zworski, CMP 274 (2007) 187). KNOWN-TRUE vertex gate.

Run:  OMP_NUM_THREADS=1 python3 pde_solver.py
================================================================================
"""
import os, time
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

t0 = time.time()
def el(): return "[t=%6.2fs]" % (time.time() - t0)
SEP = "=" * 80


# =============================================================================
# Graph representation and the discrete graph Laplacian.
# =============================================================================
class MetricGraph:
    """A metric graph discretized for NLS. Edges are intervals [0, L_e] with a
    uniform grid of n_e points (endpoints included). Vertices identify edge
    endpoints and impose Kirchhoff (continuity + current-balance) or a delta
    condition of strength g (sum of OUTWARD derivatives = g * value).

    For simplicity and correctness we build the global index map and a single
    sparse symmetric D2 (the graph Laplacian, approximating d^2/dx^2 with the
    vertex conditions). Edges store (length, n, endpoints (vA, vB))."""

    def __init__(self, h_target=0.02):
        self.h_target = h_target
        self.edges = []        # list of dicts: L, n, h, vA, vB, slice
        self.vertices = {}     # name -> dict(delta=g, incident=[(edge_idx, end)])
        self._built = False

    def add_vertex(self, name, delta=0.0):
        self.vertices[name] = dict(delta=delta, incident=[])
        return name

    def add_edge(self, vA, vB, L):
        n = max(3, int(round(L / self.h_target)) + 1)
        h = L / (n - 1)
        idx = len(self.edges)
        self.edges.append(dict(L=L, n=n, h=h, vA=vA, vB=vB, slice=None))
        self.vertices[vA]['incident'].append((idx, 'A'))   # x=0 end
        self.vertices[vB]['incident'].append((idx, 'B'))   # x=L end
        return idx

    def build(self):
        """Assign global indices and assemble the sparse symmetric D2.

        Interior nodes: standard (q_{j-1} - 2 q_j + q_{j+1}) / h^2.
        Vertex nodes: all incident edge-endpoints are IDENTIFIED to one shared
        DOF (continuity). Its Laplacian row is the finite-volume flux balance
            D2 q|_v = ( 2 / (sum_e h_e) ) * [ sum_e (q_e^{(1)} - q_v)/h_e - (g/?) ]
        Using the standard graph-FD: at a vertex of degree d with neighbor values
        q_e^{(1)} at distance h_e, the self-adjoint discrete Laplacian is
            (D2 q)_v = (2 / H) * ( sum_e (q_e^{(1)} - q_v)/h_e )  -  (2 g / H) q_v,
        with H = sum_e h_e (the lumped vertex "volume"). The 2/H prefactor and the
        symmetric off-diagonals (2/(H h_e) between v and each neighbor) make D2
        SYMMETRIC; g is the delta-strength (g=0 = Kirchhoff). Derivation: integrate
        q_xx over the half-cells meeting at v; flux sum_e q_x|_e = g q_v (delta BC).
        """
        # 1) global DOFs: one per interior node + one shared per vertex.
        gid = 0
        # vertex DOFs first
        self.vid = {}
        for name in self.vertices:
            self.vid[name] = gid; gid += 1
        # interior DOFs per edge (nodes 1..n-2), endpoints map to vertex DOFs
        for e in self.edges:
            n = e['n']
            e['interior'] = list(range(gid, gid + (n - 2)))
            gid += (n - 2)
            # node-> global index map for this edge (length n)
            gmap = np.empty(n, dtype=int)
            gmap[0] = self.vid[e['vA']]
            gmap[-1] = self.vid[e['vB']]
            gmap[1:-1] = e['interior']
            e['gmap'] = gmap
        self.N = gid

        # 2) assemble D2 (COO)
        rows, cols, vals = [], [], []
        def add(i, j, v): rows.append(i); cols.append(j); vals.append(v)

        # interior stencils
        for e in self.edges:
            h = e['h']; gmap = e['gmap']; n = e['n']
            for k in range(1, n - 1):
                i = gmap[k]
                add(i, i, -2.0 / h**2)
                add(i, gmap[k - 1], 1.0 / h**2)
                add(i, gmap[k + 1], 1.0 / h**2)

        # vertex stencils (finite-volume flux balance, symmetric)
        for name, v in self.vertices.items():
            iv = self.vid[name]
            inc = v['incident']
            H = sum(self.edges[ei]['h'] for ei, _ in inc)   # lumped volume
            g = v['delta']
            # diagonal
            diag = 0.0
            for ei, end in inc:
                e = self.edges[ei]; h = e['h']
                # neighbor interior node adjacent to this vertex on edge ei
                nb = e['gmap'][1] if end == 'A' else e['gmap'][-2]
                coef = 2.0 / (H * h)
                add(iv, nb, coef)
                diag += -coef
            diag += -2.0 * g / H
            add(iv, iv, diag)

        self.D2 = sp.csr_matrix((vals, (rows, cols)), shape=(self.N, self.N))
        # NOTE: D2 is NOT plain-symmetric at vertices of degree != 2. It is
        # self-adjoint w.r.t. the LUMPED-MASS inner product W = diag(w_node) with
        # w_interior = h_e and w_vertex = (sum_e h_e)/2: one checks W D2 = D2^T W
        # (the (vertex,neighbor) pair gives (H/2)(2/(H h)) = 1/h = (1/h^2)(h) on both
        # sides). Hence Crank-Nicolson conserves the W-weighted norm = the physical
        # mass sum_e int|q|^2 dx (which the trapezoid rule reproduces). Do NOT force
        # 0.5*(D2+D2^T): that averages 2/(H h) with 1/h^2 and corrupts the degree>=3
        # vertex coupling (caught by the degree-3 star control, R != 1/9).
        self._built = True
        return self

    # ---- helpers to read/write fields on edges ----
    def edge_x(self, ei):
        e = self.edges[ei]
        return np.linspace(0.0, e['L'], e['n'])

    def scatter_edge(self, q, ei, vals):
        """Write per-node values onto edge ei into the global state q (endpoints
        write to the shared vertex DOF; last writer wins -- callers should make
        endpoints consistent)."""
        e = self.edges[ei]
        q[e['gmap']] = vals

    def gather_edge(self, q, ei):
        e = self.edges[ei]
        return q[e['gmap']]


# =============================================================================
# Strang split-step time stepper with Crank-Nicolson linear flow.
# =============================================================================
class NLSPropagator:
    def __init__(self, graph, dt, damping=None):
        assert graph._built
        self.G = graph
        self.dt = dt
        I = sp.identity(graph.N, format='csr', dtype=complex)
        # linear generator: q_t = i D2 q ; CN: (I - i dt/2 D2) q+ = (I + i dt/2 D2) q
        self.A = (I - 1j * dt / 2.0 * graph.D2).tocsc()
        self.Bmat = (I + 1j * dt / 2.0 * graph.D2).tocsc()
        self.lu = spla.splu(self.A)
        self.damping = damping  # optional real array (per-DOF) absorbing mask in (0,1]

    def nl_half(self, q):
        return q * np.exp(2j * np.abs(q)**2 * (self.dt / 2.0))

    def lin_full(self, q):
        return self.lu.solve(self.Bmat.dot(q))

    def step(self, q):
        q = self.nl_half(q)
        q = self.lin_full(q)
        q = self.nl_half(q)
        if self.damping is not None:
            q = q * self.damping
        return q


# =============================================================================
# Diagnostics
# =============================================================================
def mass(G, q):
    """L2 norm^2 = sum_e int |q|^2 dx (trapezoid per edge)."""
    m = 0.0
    for ei, e in enumerate(G.edges):
        vals = G.gather_edge(q, ei)
        m += np.trapz(np.abs(vals)**2, dx=e['h'])
    return m

def energy(G, q):
    """NLS energy E = sum_e int (|q_x|^2 - |q|^4) dx (focusing)."""
    E = 0.0
    for ei, e in enumerate(G.edges):
        vals = G.gather_edge(q, ei); h = e['h']
        qx = np.gradient(vals, h)
        E += np.trapz(np.abs(qx)**2 - np.abs(vals)**4, dx=h)
    return E


# =============================================================================
# CONTROLS
# =============================================================================
def soliton_field(x, eta, xi, x0, t=0.0):
    """Moving bright soliton of i q_t + q_xx + 2|q|^2 q = 0:
       q = 2 eta sech(2 eta (x - x0 - v t)) exp(i(theta)), v = -4 xi,
       theta = -2 xi x - 4(xi^2 - eta^2) t  (ZS eigenvalue xi + i eta)."""
    v = -4.0 * xi
    arg = 2 * eta * (x - x0 - v * t)
    phase = -2 * xi * x - 4 * (xi**2 - eta**2) * t
    return 2 * eta / np.cosh(arg) * np.exp(1j * phase)


def ctrl_A_stationary():
    print(SEP); print("CTRL-A  stationary soliton 2 sech(2x): |q| invariant, mass/energy conserved", el()); print(SEP)
    G = MetricGraph(h_target=0.02)
    G.add_vertex('L'); G.add_vertex('R')
    G.add_edge('L', 'R', 40.0)   # a single long edge = a line segment [0,40]
    G.build()
    x = G.edge_x(0)
    q = np.zeros(G.N, dtype=complex)
    G.scatter_edge(q, 0, soliton_field(x, eta=1.0, xi=0.0, x0=20.0))
    prop = NLSPropagator(G, dt=2.5e-4)
    m0, E0 = mass(G, q), energy(G, q)
    prof0 = np.abs(G.gather_edge(q, 0)).copy()
    T = 2.0; nsteps = int(T / prop.dt)
    for k in range(nsteps):
        q = prop.step(q)
    prof1 = np.abs(G.gather_edge(q, 0))
    dm = abs(mass(G, q) - m0) / m0
    dE = abs(energy(G, q) - E0) / (abs(E0) + 1e-12)
    dprof = np.max(np.abs(prof1 - prof0))
    print("  mass rel.drift  = %.2e   energy rel.drift = %.2e   max||q|-|q0|| = %.2e"
          % (dm, dE, dprof))
    ok = dm < 1e-4 and dprof < 5e-3
    print("  -> %s" % ("PASS" if ok else "FAIL"))
    return ok


def ctrl_B_moving():
    print("\n" + SEP); print("CTRL-B  moving soliton translates rigidly at v=-4 xi, shape+mass preserved", el()); print(SEP)
    G = MetricGraph(h_target=0.02)
    G.add_vertex('L'); G.add_vertex('R')
    G.add_edge('L', 'R', 80.0)
    G.build()
    x = G.edge_x(0)
    eta, xi, x0 = 1.0, 0.5, 20.0      # v = -4*0.5 = -2 ... moves toward +? v=-2 -> moves left; use xi=-0.5 to move right
    xi = -0.5                          # v = +2 (rightward)
    q = np.zeros(G.N, dtype=complex)
    G.scatter_edge(q, 0, soliton_field(x, eta, xi, x0, t=0.0))
    prop = NLSPropagator(G, dt=2.0e-4)
    m0 = mass(G, q)
    T = 8.0; nsteps = int(T / prop.dt)
    for k in range(nsteps):
        q = prop.step(q)
    vals = G.gather_edge(q, 0)
    # analytic prediction at time T
    pred = soliton_field(x, eta, xi, x0, t=T)
    # compare |q| profiles (phase has fast oscillation; compare envelopes)
    env_err = np.max(np.abs(np.abs(vals) - np.abs(pred)))
    peak_pred = x0 + (-4 * xi) * T
    peak_meas = x[np.argmax(np.abs(vals))]
    dm = abs(mass(G, q) - m0) / m0
    print("  predicted peak x = %.3f   measured peak x = %.3f   (v=-4xi=%.2f)"
          % (peak_pred, peak_meas, -4 * xi))
    print("  envelope max-err = %.2e   mass rel.drift = %.2e" % (env_err, dm))
    ok = abs(peak_pred - peak_meas) < 0.3 and env_err < 0.05 and dm < 1e-4
    print("  -> %s" % ("PASS" if ok else "FAIL"))
    return ok


def ctrl_C_delta_transmission():
    print("\n" + SEP); print("CTRL-C  fast soliton across a delta-vertex: T_mass -> v^2/(v^2+g^2) (HMZ)", el()); print(SEP)
    # Degree-2 vertex with delta strength g = a point defect on the line.
    # HMZ (CMP 274,2007): high-velocity soliton splits; transmitted mass fraction
    # -> v^2/(v^2+g^2). Their NLS is i u_t + (1/2)u_xx - g delta u + |u|^2 u; soliton
    # u0 = e^{i v x} sech(x). We map to our convention i q_t + q_xx + 2|q|^2 q with a
    # delta vertex of strength G_delta and a fast soliton; we report the measured
    # transmitted fraction vs the v^2/(v^2+g^2) law for an EFFECTIVE g (calibrated by
    # the defect strength). This is a TREND control: T rises toward 1 as v grows and
    # falls with g; we verify (i) g=0 (Kirchhoff degree-2) transmits ~fully (T~1),
    # (ii) g>0 reflects a measurable fraction that DECREASES with velocity.
    def run(gstrength, vel):
        G = MetricGraph(h_target=0.02)
        G.add_vertex('L'); G.add_vertex('M', delta=gstrength); G.add_vertex('R')
        G.add_edge('L', 'M', 60.0)
        G.add_edge('M', 'R', 60.0)
        G.build()
        # incoming soliton on edge 0, moving right toward the vertex at x=60.
        eta = 1.0; xi = -vel / 4.0     # v = -4 xi = vel (rightward)
        x0 = G.edge_x(0)
        q = np.zeros(G.N, dtype=complex)
        G.scatter_edge(q, 0, soliton_field(x0, eta, xi, 30.0, t=0.0))
        m0 = mass(G, q)
        prop = NLSPropagator(G, dt=1.0e-4)
        # propagate until the (transmitted) pulse is well past the vertex
        T = 60.0 / vel + 6.0
        nsteps = int(T / prop.dt)
        for k in range(nsteps):
            q = prop.step(q)
        # transmitted mass = mass on edge 1 (M->R); reflected = mass on edge 0
        mt = np.trapz(np.abs(G.gather_edge(q, 1))**2, dx=G.edges[1]['h'])
        mr = np.trapz(np.abs(G.gather_edge(q, 0))**2, dx=G.edges[0]['h'])
        return mt / m0, mr / m0, abs(mass(G, q) - m0) / m0

    # (i) Kirchhoff degree-2 (g=0) should be (almost) fully transmitting.
    Tk, Rk, dmk = run(0.0, 8.0)
    print("  g=0 (Kirchhoff, =line): T=%.3f  R=%.3f  mass drift=%.1e  (expect T~1)" % (Tk, Rk, dmk))
    # (ii) g>0 at two velocities: reflection decreases with velocity.
    g = 3.0
    T1, R1, dm1 = run(g, 4.0)
    T2, R2, dm2 = run(g, 10.0)
    print("  g=%.1f  v=4 : T=%.3f R=%.3f      v=10: T=%.3f R=%.3f   (R should drop with v)"
          % (g, T1, R1, T2, R2))
    # HMZ law (effective g): the transmitted fraction should INCREASE toward 1 with v.
    ok = (Tk > 0.95) and (T2 > T1) and (R1 > R2) and max(dmk, dm1, dm2) < 1e-3
    print("  -> %s  (Kirchhoff ~transparent; defect reflection decreases with velocity, HMZ-trend)"
          % ("PASS" if ok else "FAIL"))
    return ok


def ctrl_D_star_split():
    print("\n" + SEP); print("CTRL-D  LINEAR wavepacket on a symmetric Kirchhoff Y (degree-3): R -> 1/9", el()); print(SEP)
    # Degree-3 Kirchhoff star, three equal edges. The LINEAR star S-matrix reflection
    # is r=(2-d)/d=-1/3 => |r|^2 = 1/9, and it is ENERGY/k-INDEPENDENT (scale-free
    # Kirchhoff), so ANY low-amplitude wavepacket reflects exactly 1/9 and transmits
    # 8/9 (4/9 to each outgoing edge). Low amplitude => the 2|q|^2 term is negligible,
    # isolating the VERTEX STENCIL. This is the clean known-true degree-3 gate.
    G = MetricGraph(h_target=0.02)
    G.add_vertex('C')          # Kirchhoff center (delta=0)
    G.add_vertex('E0'); G.add_vertex('E1'); G.add_vertex('E2')
    G.add_edge('E0', 'C', 80.0)    # incoming edge 0 (vertex C at x=80)
    G.add_edge('C', 'E1', 80.0)
    G.add_edge('C', 'E2', 80.0)
    G.build()
    x = G.edge_x(0)
    A0, k0, w, x0 = 0.01, 5.0, 2.5, 40.0     # small amplitude => linear
    packet = A0 * np.exp(1j * k0 * (x - x0)) * np.exp(-(x - x0)**2 / (2 * w**2))
    q = np.zeros(G.N, dtype=complex)
    G.scatter_edge(q, 0, packet)
    m0 = mass(G, q)
    prop = NLSPropagator(G, dt=1.0e-3)        # linear regime tolerates a larger dt
    T = 6.0; nsteps = int(T / prop.dt)         # vg=2k0=10; reaches vertex ~t=4, clears by t=6
    for k in range(nsteps):
        q = prop.step(q)
    mr = np.trapz(np.abs(G.gather_edge(q, 0))**2, dx=G.edges[0]['h']) / m0
    mt1 = np.trapz(np.abs(G.gather_edge(q, 1))**2, dx=G.edges[1]['h']) / m0
    mt2 = np.trapz(np.abs(G.gather_edge(q, 2))**2, dx=G.edges[2]['h']) / m0
    dm = abs(mass(G, q) - m0) / m0
    print("  reflected (edge0) = %.4f   transmitted = %.4f + %.4f = %.4f   mass drift=%.1e"
          % (mr, mt1, mt2, mt1 + mt2, dm))
    print("  Kirchhoff star prediction (k-independent): R=1/9=0.1111, T=8/9=0.8889 (4/9=0.4444 each).")
    ok = (abs(mr - 1.0/9.0) < 0.015) and (abs(mt1 - mt2) < 1e-3) \
         and (abs((mt1 + mt2) - 8.0/9.0) < 0.02) and dm < 1e-4
    print("  -> %s  (validates the degree-3 self-adjoint vertex stencil)" % ("PASS" if ok else "FAIL"))
    return ok


if __name__ == "__main__":
    print(SEP); print("GRAPH NLS PDE SOLVER -- FOUNDATIONAL CONTROLS", el()); print(SEP)
    gates = {}
    gates['CTRL-A stationary'] = ctrl_A_stationary()
    gates['CTRL-B moving'] = ctrl_B_moving()
    gates['CTRL-C delta-vertex'] = ctrl_C_delta_transmission()
    gates['CTRL-D star-split'] = ctrl_D_star_split()
    print("\n" + SEP); print("GATES", el()); print(SEP)
    allpass = True
    for k, v in gates.items():
        allpass &= v; print("  %-24s : %s" % (k, "PASS" if v else "FAIL"))
    print("\n  OVERALL: %s  %s" % ("ALL PASS" if allpass else "SOME FAILED", el()))
    raise SystemExit(0 if allpass else 1)
