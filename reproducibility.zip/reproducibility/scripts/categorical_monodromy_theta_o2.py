"""cat_lax5 Case Study III on a network: the vertex is a defect worldline.  B^sing_tx = q_v(t,lam) delta(x-v),
fake flatness => t(q_v) = [[V]]_v = vertex curvature (the ell_1 datum).  Defect 2-holonomy between germs i,j at v:
    D_v[i<-j](t) = W_{v,i}(t) W_{v,j}(t)^{-1},   W_{v,i} = time-ordered exp of the germ's own time-Lax matrix V_i(v,t).
Dressed (categorical) monodromy of a directed loop = ordered product of edge transfers and defect insertions.
Exact consequences to be verified on the Kirchhoff PDE run (theta 6,10,8; soliton on e2; lam = 0.6):
  (1) every dressed loop trace is conserved                (cat_lax5 Prop. defect-conj, graph version);
  (2) two loops departing the base vertex along the SAME germ are conjugated by the same W  => kappa_cat conserved;
  (3) loops departing along DIFFERENT germs are conjugated by different W => kappa_cat drifts (base = germ, not vertex);
  (4) undressed traces / kappa drift O(1) (reference).
"""
import sys, os, time, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import pde_solver as P, pde_solver2 as P2
inv = np.linalg.inv; t0 = time.time(); lam = 0.6

def Vmat(q, qx):
    return np.array([[-2j*lam**2 + 1j*abs(q)**2, 2*lam*q + 1j*qx],
                     [-2*lam*np.conj(q) + 1j*np.conj(qx), 2j*lam**2 - 1j*abs(q)**2]])
def expm2(M):                      # traceless 2x2: M^2 = -det(M) I
    s = np.sqrt(-np.linalg.det(M) + 0j)
    return np.eye(2) + M if abs(s) < 1e-13 else np.cosh(s)*np.eye(2) + (np.sinh(s)/s)*M
def transfer(qarr, h):
    T = np.eye(2, dtype=complex)
    for qq in qarr:
        w = np.sqrt(lam**2 + abs(qq)**2); Um = np.array([[-1j*lam, qq], [-np.conj(qq), 1j*lam]])
        T = (np.cos(w*h)*np.eye(2) + (np.sin(w*h)/w)*Um) @ T
    return T
def mid(a): return 0.5*(a[1:] + a[:-1])
def dq_start(a, h): return (-11*a[0] + 18*a[1] - 9*a[2] + 2*a[3])/(6*h)
def dq_end(a, h):   return (11*a[-1] - 18*a[-2] + 9*a[-3] - 2*a[-4])/(6*h)

G = P2.MetricGraph2(h_target=0.02); G.add_vertex('A'); G.add_vertex('B')
E = [G.add_edge('A', 'B', L) for L in (6.0, 10.0, 8.0)]; G.build()
hs = [G.edges[e]['h'] for e in E]
q = np.zeros(G.N, dtype=complex); G.scatter_edge(q, E[1], P.soliton_field(G.edge_x(E[1]), 0.8, -0.5, 5.0))
dt = 2e-4; T_end = 6.0; nsteps = int(round(T_end/dt)); every = 100
prop = P2.NLSPropagator2(G, dt)

def germV(qv, vertex, e, orient):        # orient +1: edge's A->B coordinate; -1: reversed coordinate (d/dx' = -d/dx)
    arr = G.gather_edge(qv, E[e]); h = hs[e]
    return Vmat(arr[0], orient*dq_start(arr, h)) if vertex == 'A' else Vmat(arr[-1], orient*dq_end(arr, h))
germs = [(v, e, o) for v in ('A', 'B') for e in (0, 1, 2) for o in (+1, -1)]
W = {g: np.eye(2, dtype=complex) for g in germs}
Vprev = {g: germV(q, *g) for g in germs}

def transfers(qv):
    T = {}
    for e in (0, 1, 2):
        arr = mid(G.gather_edge(qv, E[e])); T[(e, +1)] = transfer(arr, hs[e]); T[(e, -1)] = transfer(arr[::-1], hs[e])
    return T
g1f, g1r, g2f, g2r, g3f, g3r = (0, 1), (0, -1), (1, 1), (1, -1), (2, 1), (2, -1)
def dressed(T, W):
    D = lambda v, i, j: W[(v,)+i] @ inv(W[(v,)+j])          # insertion when passing from germ j to germ i at v
    T1  = D('A', g1f, g2r) @ T[g2r] @ D('B', g2r, g1f) @ T[g1f]     # e1 fwd, e2 rev : departs A along e1
    T2  = D('A', g3f, g2r) @ T[g2r] @ D('B', g2r, g3f) @ T[g3f]     # e3 fwd, e2 rev : departs A along e3
    T1p = D('A', g2f, g1r) @ T[g1r] @ D('B', g1r, g2f) @ T[g2f]     # e2 fwd, e1 rev : departs A along e2
    T2p = D('A', g2f, g3r) @ T[g3r] @ D('B', g3r, g2f) @ T[g2f]     # e2 fwd, e3 rev : departs A along e2
    return T1, T2, T1p, T2p
def kap(X, Y): return np.trace(X @ Y @ inv(X) @ inv(Y)) - 2
tr = np.trace
T0 = transfers(q); D0 = dressed(T0, W)
ref = dict(t1=tr(D0[0]), t2=tr(D0[1]), t1p=tr(D0[2]), t2p=tr(D0[3]), kc=kap(D0[0], D0[1]), kcp=kap(D0[2], D0[3]),
           h1=tr(T0[g2r] @ T0[g1f]), ku=kap(T0[g2r] @ T0[g1f], T0[g2r] @ T0[g3f]))
rows = []
for k in range(1, nsteps+1):
    q = prop.step(q)
    Vnow = {g: germV(q, *g) for g in germs}
    for g in germs: W[g] = expm2(dt*0.5*(Vprev[g] + Vnow[g])) @ W[g]
    Vprev = Vnow
    if k % every == 0:
        t = k*dt; T = transfers(q); T1, T2, T1p, T2p = dressed(T, W)
        H1c = T[g2r] @ T[g1f]; H2c = T[g2r] @ T[g3f]
        WA1 = W[('A', 0, 1)]; pred = WA1 @ D0[0] @ inv(WA1)
        rows.append(dict(t=t, t1=tr(T1), t2=tr(T2), t1p=tr(T1p), t2p=tr(T2p), kc=kap(T1, T2), kcp=kap(T1p, T2p),
                         h1=tr(H1c), ku=kap(H1c, H2c), conj=np.linalg.norm(T1 - pred)/np.linalg.norm(T1)))
print(f"[{time.time()-t0:5.1f}s] theta (6,10,8) Kirchhoff, lam={lam}: dressed (categorical) vs undressed loop data")
print("   t    tr𝓣1      tr𝓣2      tr𝓣1'     tr𝓣2'   | κ_cat(e1,e3 dep.) κ_cat'(common e2 dep.) | tr H1 undressed  κ undressed | ‖𝓣1−W𝓣1(0)W⁻¹‖/‖𝓣1‖")
def f(z): return f"{z.real:+7.4f}"
print(f"  0.00  {f(ref['t1'])}  {f(ref['t2'])}  {f(ref['t1p'])}  {f(ref['t2p'])}  |   {f(ref['kc'])}          {f(ref['kcp'])}          |   {f(ref['h1'])}        {f(ref['ku'])}     |   0")
for r in rows[19::20]:
    print(f"  {r['t']:4.2f}  {f(r['t1'])}  {f(r['t2'])}  {f(r['t1p'])}  {f(r['t2p'])}  |   {f(r['kc'])}          {f(r['kcp'])}          |   {f(r['h1'])}        {f(r['ku'])}     |   {r['conj']:.1e}")
dev = lambda key: max(abs(r[key] - ref[key]) for r in rows)
print("\n max |deviation from t=0| over the run:")
print(f"   dressed traces  tr𝓣1 {dev('t1'):.3e}   tr𝓣2 {dev('t2'):.3e}   tr𝓣1' {dev('t1p'):.3e}   tr𝓣2' {dev('t2p'):.3e}")
print(f"   κ_cat  (loops departing along e1 and e3)  {dev('kc'):.3e}      κ_cat' (both departing along e2)  {dev('kcp'):.3e}")
print(f"   undressed: tr H1 {dev('h1'):.3e}   κ {dev('ku'):.3e}")
print(f"   direct conjugation check max ‖𝓣1(t) − W_A,e1 𝓣1(0) W⁻¹‖/‖𝓣1‖ = {max(r['conj'] for r in rows):.2e}")
print(f"[{time.time()-t0:5.1f}s] done")
