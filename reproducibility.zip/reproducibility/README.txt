Computational support for Isospectrality defect of the nonlinear Schrodinger equation on looped networks: vertex curvature, dressed monodromy, and local integrable junctions
Author: A. T. Patrascu

This package accompanies the approved 3 October 2026 manuscript. It contains the numerical solvers, figure generators, independently checked local-Lax and standing-wave controls, and archived numerical outputs used by the manuscript. It contains no manuscript drafts, correspondence, reviewer reports, or internal research logs.

Install the packages listed in requirements.txt. Create an empty figures directory (mkdir -p figures). Run from this directory, using Python 3:
  PYSCF_MAX_MEMORY=2000 python scripts/verify_lax_controls.py
  python scripts/make_schematic.py
  python scripts/make_figures_v2.py --part 1
  python scripts/make_figures_v2.py --part 2
The first command writes scripts/control_results.json. Figure commands write figures/*.pdf and figures/*.png, and data/v2_numbers_part1.json and data/v2_numbers_part2.json. The schematic corresponds to Figure 1; the four v2_fig1--4 plots correspond to Figures 2--5. On a laptop the figure computations take several minutes.

Further finite-grid checks (longer runs):
  python scripts/vertex_curvature_defect_o2.py theta 0.02 0.0002
  python scripts/vertex_curvature_defect_o2.py theta 0.01 0.00005
  python scripts/vertex_curvature_defect_o2.py ring 0.02 0.0002
  python scripts/categorical_monodromy_theta_o2.py
  python scripts/pde_solver2.py
  python scripts/solver2_linear_star_test.py
  python scripts/solver2_nonlinear_star_test.py

The *_o2 scripts use second-order vertex constraints; pde_solver.py supplies shared definitions and the historical first-order comparison solver. Files in data are archived numerical results; the .npy files contain sample arrays and their paired JSON files contain parameters and diagnostics. The other .txt files contain numerical control output, not editorial or workflow records.

Interpretation follows the manuscript: travel-adapted reversal is distinct from inverse-path transport; conservation after history dressing alone does not establish standard integrability. Pointwise two-grid defects are not monotone, and finite-resolution checks are not certified continuum error bounds. The current paper makes no universal degree-three no-go claim.
